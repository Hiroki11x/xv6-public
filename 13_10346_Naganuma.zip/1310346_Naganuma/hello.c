#include "types.h"
#include "stat.h"
#include "user.h"
int main (void) {
 printf(1, "Hello, World!\n");
 exit();
}